Texture edit: R398

请在PMX Editor中修改并应用贴图。如果你使用的是泄露版模型，你可能需要调整材质的UV。
具体做法是在UV编辑器中，将材质宽度放大三倍（0,3），位置下移1倍(1,0)。

You can apply the custom textures in PMX Editor by changing the path of the texture.
Sometimes you have to adjust the UV of the textures to make it works normally. Go follow these steps if you have such issue:
1) Open UV Editor in PMX Editor.
2) Select the UV, HORIZONTALLY upscale it in 3x, then VERTICALLY move it in 1x. Make sure you applied the adjustment to the model.